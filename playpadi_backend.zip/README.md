# PlayPadi Backend
Run npm install then npm start